A simple daily agenda for a grandmother suffering from Alzheimer

